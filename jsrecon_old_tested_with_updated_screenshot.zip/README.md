# JSRecon — Cyborg Edition V1
### by Rahul Masal

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║        ██╗███████╗██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗                  ║
║        ██║██╔════╝██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║                  ║
║        ██║███████╗██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║                  ║
║   ██   ██║╚════██║██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║                  ║
║   ╚█████╔╝███████║██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║                  ║
║    ╚════╝ ╚══════╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝                  ║
║              ── CYBORG EDITION V1 ── by Rahul Masal ──                          ║
╚══════════════════════════════════════════════════════════════════════════════════╝
```

> ⚠️ **For authorized bug bounty & penetration testing use only.**
> Unauthorized use against systems you don't own or have written permission for is illegal.

---

## 📋 What It Does

JSRecon is a **fully automated JavaScript reconnaissance tool** built for professional bug bounty hunters. It chains together industry-standard tools into one smooth pipeline:

| Phase | Action |
|-------|--------|
| 1 | Subdomain enumeration (subfinder) + live probing (httpx) |
| 2 | Sensitive path discovery (401/403/200 checks, false-positive filtering by content-length) |
| 3 | URL collection via Waybackurls, GoSpider, Katana |
| 4 | URL filtering by extensions, keywords, and secret patterns |
| 5 | JS file download, beautification, and deep secret scanning |
| 6 | Screenshots of all live targets (gowitness) |
| 7 | Human-readable final summary report |

---

## 🔍 What It Finds in JS Files

- **AWS keys** — `AKIA...` access key IDs + secret keys
- **API keys & tokens** — generic + service-specific (Stripe, Twilio, SendGrid, Mailgun, GitHub)
- **Firebase / Google** — `AIza...` keys, project configs
- **Database credentials** — JDBC strings, MongoDB URIs, MySQL passwords
- **OAuth / SSO** — client_id, client_secret, bearer tokens
- **Private keys & certs** — PEM blocks, RSA keys
- **Webhooks** — Slack, Discord, Telegram
- **JWT secrets** — jwt_secret, JWT_SECRET
- **Heroku, Datadog, New Relic, Sentry** keys
- **Endpoints inside JS** — `/api/v1/...`, `/graphql`, `/admin/...`
- **URLs inside JS** — hardcoded endpoints, base URLs, CDN links
- **Environment configs** — `process.env.*`, `.env` references

---

## 🚀 Installation

```bash
# 1. Clone or download jsrecon.py
# 2. Run the installer
chmod +x install.sh
./install.sh

# 3. Make sure ~/go/bin is in your PATH
export PATH=$PATH:$HOME/go/bin
```

### Manual tool install (if needed)
```bash
# Go tools
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/jaeles-project/gospider@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/sensepost/gowitness@latest

# Python packages
pip3 install jsbeautifier requests
```

---

## 💻 Usage

```bash
# Single domain
python3 jsrecon.py -d example.com

# Domain list
python3 jsrecon.py -l domains.txt

# Skip screenshots (faster)
python3 jsrecon.py -d example.com --skip-screenshots

# Skip wayback (faster, less noise)
python3 jsrecon.py -d example.com --skip-wayback

# Skip GoSpider + Katana
python3 jsrecon.py -d example.com --skip-spider

# JS-only mode (pipe in JS URLs directly)
cat js_urls.txt | python3 jsrecon.py -d example.com --js-only

# Custom thread count for JS analysis
python3 jsrecon.py -d example.com --threads 20
```

---

## 📁 Output Structure

```
jsrecon/
└── output/
    └── <target>/
        ├── 01_subdomains/
        │   ├── subfinder_all.txt        ← all discovered subdomains
        │   └── live_subdomains.txt      ← httpx-verified live hosts
        ├── 02_sensitive_paths/
        │   ├── paths_to_check.txt       ← all generated path URLs
        │   ├── raw_findings.txt         ← 200 OK hits
        │   └── findings_unique.txt      ← deduplicated (no honeypots)
        ├── 03_wayback/
        │   └── wayback_urls.txt
        ├── 04_gospider/
        │   ├── sites.txt
        │   ├── gospider_output/         ← raw gospider output
        │   └── gospider_urls.txt
        ├── 05_katana/
        │   └── katana_urls.txt
        ├── 06_combined_urls/
        │   ├── urls.txt                 ← all combined unique URLs
        │   ├── liveurls.txt             ← httpx 200-OK verified
        │   ├── finalurls_with_ct.txt    ← with content-type header
        │   ├── sensitive_extension_urls.txt
        │   ├── keyword_urls.txt
        │   └── secret_pattern_urls.txt  ← regex-matched secret candidates
        ├── 07_js_analysis/
        │   ├── js_urls.txt              ← all .js file URLs
        │   ├── jsfileurls.txt           ← URLs extracted FROM JS files
        │   └── downloaded/              ← beautified JS files
        ├── 08_secrets/
        │   ├── js_secrets.txt           ← human-readable secrets report
        │   └── js_secrets.json          ← machine-readable JSON
        ├── 09_endpoints/
        │   └── api_endpoints.txt        ← API endpoints extracted from JS
        ├── 10_screenshots/
        │   ├── captures/                ← PNG screenshots
        │   └── screenshot_report.html   ← visual HTML gallery
        └── 11_reports/
            └── summary_report.txt       ← final summary
```

---

## 🛡️ Sensitive Paths Checked (47 paths)

```
/.env  /.env.production  /.env.local  /.git/config
/config.js  /config.json  /settings.json  /database.json
/firebase.json  /package.json  /package-lock.json
/api_keys.json  /credentials.json  /secrets.json
/google-services.json  /wp-config.php  /docker-compose.yml
/swagger.json  /openapi.json  /graphql  /graphiql
/debug.log  /logs/debug.log  /backup.zip  /backup.sql
... and more
```

---

## 📝 Notes

- **False positive filtering**: sensitive path results are deduplicated by content-length per domain, removing catch-all pages
- **JS beautifier**: uses `jsbeautifier` Python package if installed, falls back to built-in formatter
- **Concurrent analysis**: JS files analyzed in parallel (default 10 threads, configurable)
- **All output is stored locally** in `jsrecon/output/<target>/`

---

## 📜 Legal

This tool is intended for **authorized security testing only**.  
Always obtain written permission before testing any target.  
The author Rahul Masal is not responsible for any misuse.
